/*eslint strict:0*/
casper.test.begin('true', 1, function(test) {
    test.assert(true);
    test.done();
});
